import Rating from "./pages/Rating"


function App() {
  
  return (
    <>
   <Rating/>
    </>
  )
}

export default App
